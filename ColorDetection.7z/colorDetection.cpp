/*------------------------------------------------------------------------------------------*\
   This file contains material supporting chapter 3 of the cookbook:  
   Computer Vision Programming using the OpenCV Library. 
   by Robert Laganiere, Packt Publishing, 2011.

   This program is free software; permission is hereby granted to use, copy, modify, 
   and distribute this source code, or portions thereof, for any purpose, without fee, 
   subject to the restriction that the copyright notice may not be removed 
   or altered from any source or altered source distribution. 
   The software is released on an as-is basis and without any warranties of any kind. 
   In particular, the software is not guaranteed to be fault-tolerant or free from failure. 
   The author disclaims all warranties with regard to this software, any use, 
   and any consequent failure, is purely the responsibility of the user.
 
   Copyright (C) 2010-2011 Robert Laganiere, www.laganiere.name
\*------------------------------------------------------------------------------------------*/

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

#include "myopencv.h"
#include "colordetector.h"

//using namespace std;

//int main()
int ColorDetection()
{
	// Create image processor object
	ColorDetector cdetect;
#if 0
	// Read input image
	cv::Mat image= cv::imread("boldt.jpg");
	if (!image.data)
		return 0; 
#else
	std::string arg = "2";
	VideoCapture capture(arg); //try to open string, this will attempt to open it as a video file
	if (!capture.isOpened()) //if this fails, try to open as a video camera, through the use of an integer param
		capture.open(atoi(arg.c_str()));
	if (!capture.isOpened()) {
		std::cerr << "Failed to open a video device or video file!\n" << std::endl;
//		help(av);
		return 1;
	}
	cv::Mat image;
	for (;;) {
		capture >> image;
		if (image.empty())
			break;
#endif
	   // set input parameters
		//cdetect.setTargetColor(130,190,230); // here blue sky
		cdetect.setTargetColor(255,100,100); // here near red

	   // Read image, process it and display the result
		cv::namedWindow("result");
		cv::imshow("result", cdetect.process(image));
		cv::imshow("original", image);
#if 0
	cv::waitKey();
#else
		char key = (char)waitKey(5); //delay N millis, usually long enough to display and capture input
		switch (key) {
		case 'q':
		case 'Q':
		case 27: //escape key
			return 0;
		case ' ': //Save an image
			//sprintf(filename,"filename%.3d.jpg",n++);
			//imwrite(filename,frame);
			//cout << "Saved " << filename << endl;
			break;
		default:
			break;
		}
	}
	return 0;
#endif

	return 0;
}

