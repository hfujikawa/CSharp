﻿namespace ImagePreviewListView
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.listView1 = new System.Windows.Forms.ListView();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.stripBtnNew = new System.Windows.Forms.ToolStripButton();
            this.btnOpen = new System.Windows.Forms.ToolStripButton();
            this.btnSave = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.txtZoom = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.cbCentZoom = new System.Windows.Forms.ComboBox();
            this.chkLoad = new System.Windows.Forms.CheckBox();
            this.lbDefect = new System.Windows.Forms.ListBox();
            this.tbThreshold = new System.Windows.Forms.TextBox();
            this.chkBoxThresh = new System.Windows.Forms.CheckBox();
            this.tbarThreshold = new System.Windows.Forms.TrackBar();
            this.tsSide = new System.Windows.Forms.ToolStrip();
            this.btnWorkRect = new System.Windows.Forms.ToolStripButton();
            this.btnDraw = new System.Windows.Forms.ToolStripButton();
            this.cbPenType = new System.Windows.Forms.ToolStripComboBox();
            this.btnMask = new System.Windows.Forms.ToolStripButton();
            this.cbMaskType = new System.Windows.Forms.ToolStripComboBox();
            this.btnSelect = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnDone = new System.Windows.Forms.ToolStripButton();
            this.btnRegist = new System.Windows.Forms.ToolStripButton();
            this.btnDelete = new System.Windows.Forms.ToolStripButton();
            this.btnCopy = new System.Windows.Forms.ToolStripButton();
            this.btnPaste = new System.Windows.Forms.ToolStripButton();
            this.pbPreview = new System.Windows.Forms.PictureBox();
            this.pbZoom = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbarThreshold)).BeginInit();
            this.tsSide.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPreview)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbZoom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.listView1.Location = new System.Drawing.Point(25, 204);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(183, 222);
            this.listView1.TabIndex = 1;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            this.listView1.MouseLeave += new System.EventHandler(this.listView1_MouseLeave);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stripBtnNew,
            this.btnOpen,
            this.btnSave,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton5,
            this.txtZoom,
            this.toolStripButton8,
            this.toolStripButton7});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1058, 27);
            this.toolStrip1.TabIndex = 5;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // stripBtnNew
            // 
            this.stripBtnNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.stripBtnNew.Image = ((System.Drawing.Image)(resources.GetObject("stripBtnNew.Image")));
            this.stripBtnNew.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.stripBtnNew.Name = "stripBtnNew";
            this.stripBtnNew.Size = new System.Drawing.Size(23, 24);
            this.stripBtnNew.Text = "toolStripButton1";
            this.stripBtnNew.Click += new System.EventHandler(this.stripBtnNew_Click);
            // 
            // btnOpen
            // 
            this.btnOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnOpen.Image = ((System.Drawing.Image)(resources.GetObject("btnOpen.Image")));
            this.btnOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(23, 24);
            this.btnOpen.Text = "Open";
            this.btnOpen.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // btnSave
            // 
            this.btnSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(23, 24);
            this.btnSave.Text = "Save";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(23, 24);
            this.toolStripButton2.Text = "toolStripButton2";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(23, 24);
            this.toolStripButton3.Text = "toolStripButton3";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(23, 24);
            this.toolStripButton4.Text = "toolStripButton4";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(23, 24);
            this.toolStripButton5.Text = "toolStripButton5";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // txtZoom
            // 
            this.txtZoom.Name = "txtZoom";
            this.txtZoom.Size = new System.Drawing.Size(100, 27);
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton8.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton8.Image")));
            this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Size = new System.Drawing.Size(23, 24);
            this.toolStripButton8.Text = "Option";
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(23, 24);
            this.toolStripButton7.Text = "Reset";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 539);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1058, 25);
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(35, 20);
            this.toolStripStatusLabel1.Text = "Info";
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(395, 3);
            this.trackBar1.Maximum = 400;
            this.trackBar1.Minimum = 10;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(301, 56);
            this.trackBar1.TabIndex = 8;
            this.trackBar1.Value = 100;
            this.trackBar1.ValueChanged += new System.EventHandler(this.trackBar1_ValueChanged);
            // 
            // cbCentZoom
            // 
            this.cbCentZoom.FormattingEnabled = true;
            this.cbCentZoom.Items.AddRange(new object[] {
            "zero origin",
            "image center"});
            this.cbCentZoom.Location = new System.Drawing.Point(797, 37);
            this.cbCentZoom.Name = "cbCentZoom";
            this.cbCentZoom.Size = new System.Drawing.Size(121, 23);
            this.cbCentZoom.TabIndex = 9;
            this.cbCentZoom.SelectedIndexChanged += new System.EventHandler(this.cbCentZoom_SelectedIndexChanged);
            // 
            // chkLoad
            // 
            this.chkLoad.AutoSize = true;
            this.chkLoad.Location = new System.Drawing.Point(798, 16);
            this.chkLoad.Name = "chkLoad";
            this.chkLoad.Size = new System.Drawing.Size(122, 19);
            this.chkLoad.TabIndex = 10;
            this.chkLoad.Text = "Startup Atatch";
            this.chkLoad.UseVisualStyleBackColor = true;
            // 
            // lbDefect
            // 
            this.lbDefect.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbDefect.FormattingEnabled = true;
            this.lbDefect.ItemHeight = 15;
            this.lbDefect.Location = new System.Drawing.Point(806, 226);
            this.lbDefect.Name = "lbDefect";
            this.lbDefect.Size = new System.Drawing.Size(131, 169);
            this.lbDefect.TabIndex = 11;
            this.lbDefect.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // tbThreshold
            // 
            this.tbThreshold.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.tbThreshold.Location = new System.Drawing.Point(375, 503);
            this.tbThreshold.Name = "tbThreshold";
            this.tbThreshold.Size = new System.Drawing.Size(35, 22);
            this.tbThreshold.TabIndex = 12;
            // 
            // chkBoxThresh
            // 
            this.chkBoxThresh.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.chkBoxThresh.AutoSize = true;
            this.chkBoxThresh.Location = new System.Drawing.Point(277, 506);
            this.chkBoxThresh.Name = "chkBoxThresh";
            this.chkBoxThresh.Size = new System.Drawing.Size(92, 19);
            this.chkBoxThresh.TabIndex = 13;
            this.chkBoxThresh.Text = "Threshold";
            this.chkBoxThresh.UseVisualStyleBackColor = true;
            this.chkBoxThresh.CheckedChanged += new System.EventHandler(this.chkBoxThresh_CheckedChanged);
            // 
            // tbarThreshold
            // 
            this.tbarThreshold.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.tbarThreshold.LargeChange = 1;
            this.tbarThreshold.Location = new System.Drawing.Point(439, 498);
            this.tbarThreshold.Maximum = 255;
            this.tbarThreshold.Minimum = 1;
            this.tbarThreshold.Name = "tbarThreshold";
            this.tbarThreshold.Size = new System.Drawing.Size(224, 56);
            this.tbarThreshold.TabIndex = 17;
            this.tbarThreshold.Value = 100;
            this.tbarThreshold.ValueChanged += new System.EventHandler(this.tbarThreshold_ValueChanged);
            // 
            // tsSide
            // 
            this.tsSide.Dock = System.Windows.Forms.DockStyle.Right;
            this.tsSide.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnWorkRect,
            this.btnDraw,
            this.cbPenType,
            this.btnMask,
            this.cbMaskType,
            this.btnSelect,
            this.toolStripSeparator1,
            this.btnDone,
            this.btnRegist,
            this.btnDelete,
            this.btnCopy,
            this.btnPaste});
            this.tsSide.Location = new System.Drawing.Point(999, 27);
            this.tsSide.Name = "tsSide";
            this.tsSide.Size = new System.Drawing.Size(59, 512);
            this.tsSide.TabIndex = 18;
            this.tsSide.Text = "toolStrip2";
            // 
            // btnWorkRect
            // 
            this.btnWorkRect.AutoSize = false;
            this.btnWorkRect.Checked = true;
            this.btnWorkRect.CheckOnClick = true;
            this.btnWorkRect.CheckState = System.Windows.Forms.CheckState.Checked;
            this.btnWorkRect.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnWorkRect.Image = global::ImagePreviewListView.Properties.Resources.WorkRectOn32;
            this.btnWorkRect.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnWorkRect.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnWorkRect.Name = "btnWorkRect";
            this.btnWorkRect.Size = new System.Drawing.Size(48, 48);
            this.btnWorkRect.CheckedChanged += new System.EventHandler(this.btnWorkRect_CheckedChanged);
            // 
            // btnDraw
            // 
            this.btnDraw.AutoSize = false;
            this.btnDraw.CheckOnClick = true;
            this.btnDraw.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnDraw.Image = global::ImagePreviewListView.Properties.Resources.LinePen;
            this.btnDraw.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnDraw.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnDraw.Name = "btnDraw";
            this.btnDraw.Size = new System.Drawing.Size(48, 48);
            this.btnDraw.Text = "LinePen";
            this.btnDraw.CheckedChanged += new System.EventHandler(this.btnDraw_CheckedChanged);
            // 
            // cbPenType
            // 
            this.cbPenType.AutoCompleteCustomSource.AddRange(new string[] {
            "Line",
            "Polygon"});
            this.cbPenType.AutoSize = false;
            this.cbPenType.Font = new System.Drawing.Font("Yu Gothic UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.cbPenType.Items.AddRange(new object[] {
            "線",
            "多角形",
            "B-Spline"});
            this.cbPenType.Name = "cbPenType";
            this.cbPenType.Size = new System.Drawing.Size(56, 25);
            this.cbPenType.SelectedIndexChanged += new System.EventHandler(this.cbPenType_SelectedIndexChanged);
            // 
            // btnMask
            // 
            this.btnMask.AutoSize = false;
            this.btnMask.CheckOnClick = true;
            this.btnMask.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnMask.Image = global::ImagePreviewListView.Properties.Resources.MaskPen;
            this.btnMask.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnMask.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnMask.Name = "btnMask";
            this.btnMask.Size = new System.Drawing.Size(48, 48);
            this.btnMask.Text = "Mask";
            // 
            // cbMaskType
            // 
            this.cbMaskType.AutoCompleteCustomSource.AddRange(new string[] {
            "線",
            "矩形",
            "多角形"});
            this.cbMaskType.AutoSize = false;
            this.cbMaskType.Font = new System.Drawing.Font("Yu Gothic UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.cbMaskType.Items.AddRange(new object[] {
            "線",
            "矩形",
            "多角形"});
            this.cbMaskType.Name = "cbMaskType";
            this.cbMaskType.Size = new System.Drawing.Size(56, 25);
            // 
            // btnSelect
            // 
            this.btnSelect.AutoSize = false;
            this.btnSelect.CheckOnClick = true;
            this.btnSelect.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSelect.Image = global::ImagePreviewListView.Properties.Resources.Select;
            this.btnSelect.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(48, 48);
            this.btnSelect.Text = "toolStripButton1";
            this.btnSelect.CheckedChanged += new System.EventHandler(this.btnSelect_CheckedChanged);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(56, 6);
            // 
            // btnDone
            // 
            this.btnDone.AutoSize = false;
            this.btnDone.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnDone.Image = global::ImagePreviewListView.Properties.Resources.StatusAnnotations_Complete_and_ok_32xLG_color;
            this.btnDone.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnDone.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(48, 48);
            this.btnDone.Text = "Done";
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // btnRegist
            // 
            this.btnRegist.AutoSize = false;
            this.btnRegist.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRegist.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnRegist.Font = new System.Drawing.Font("Yu Gothic UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnRegist.Image = global::ImagePreviewListView.Properties.Resources.add;
            this.btnRegist.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnRegist.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnRegist.Name = "btnRegist";
            this.btnRegist.Size = new System.Drawing.Size(48, 48);
            this.btnRegist.Text = "A";
            this.btnRegist.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnRegist.Click += new System.EventHandler(this.btnRegist_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.AutoSize = false;
            this.btnDelete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnDelete.Image = global::ImagePreviewListView.Properties.Resources.delete_2;
            this.btnDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(48, 48);
            this.btnDelete.Text = "Delete";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnCopy
            // 
            this.btnCopy.AutoSize = false;
            this.btnCopy.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnCopy.Image = global::ImagePreviewListView.Properties.Resources.COPY;
            this.btnCopy.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnCopy.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Size = new System.Drawing.Size(48, 48);
            this.btnCopy.Text = "Copy";
            this.btnCopy.Visible = false;
            // 
            // btnPaste
            // 
            this.btnPaste.AutoSize = false;
            this.btnPaste.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnPaste.Image = global::ImagePreviewListView.Properties.Resources.paste;
            this.btnPaste.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPaste.Name = "btnPaste";
            this.btnPaste.Size = new System.Drawing.Size(48, 48);
            this.btnPaste.Text = "Paste";
            this.btnPaste.Visible = false;
            // 
            // pbPreview
            // 
            this.pbPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbPreview.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pbPreview.Location = new System.Drawing.Point(798, 65);
            this.pbPreview.Name = "pbPreview";
            this.pbPreview.Size = new System.Drawing.Size(200, 150);
            this.pbPreview.TabIndex = 3;
            this.pbPreview.TabStop = false;
            this.pbPreview.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox3_MouseDown);
            this.pbPreview.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox3_MouseMove);
            this.pbPreview.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox3_MouseUp);
            // 
            // pbZoom
            // 
            this.pbZoom.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pbZoom.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pbZoom.Location = new System.Drawing.Point(219, 63);
            this.pbZoom.Name = "pbZoom";
            this.pbZoom.Size = new System.Drawing.Size(576, 432);
            this.pbZoom.TabIndex = 2;
            this.pbZoom.TabStop = false;
            this.pbZoom.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox2_Paint);
            this.pbZoom.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseDown);
            this.pbZoom.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseMove);
            this.pbZoom.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseUp);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pictureBox1.Location = new System.Drawing.Point(28, 63);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(180, 135);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1058, 564);
            this.Controls.Add(this.tsSide);
            this.Controls.Add(this.tbarThreshold);
            this.Controls.Add(this.chkBoxThresh);
            this.Controls.Add(this.tbThreshold);
            this.Controls.Add(this.lbDefect);
            this.Controls.Add(this.chkLoad);
            this.Controls.Add(this.cbCentZoom);
            this.Controls.Add(this.trackBar1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.pbPreview);
            this.Controls.Add(this.pbZoom);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "MainForm";
            this.Text = "Defect Detection";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbarThreshold)).EndInit();
            this.tsSide.ResumeLayout(false);
            this.tsSide.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPreview)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbZoom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.PictureBox pbZoom;
        private System.Windows.Forms.PictureBox pbPreview;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btnOpen;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripTextBox txtZoom;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripButton btnSave;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.ComboBox cbCentZoom;
        private System.Windows.Forms.CheckBox chkLoad;
        private System.Windows.Forms.ToolStripButton stripBtnNew;
        private System.Windows.Forms.ListBox lbDefect;
        private System.Windows.Forms.TextBox tbThreshold;
        private System.Windows.Forms.CheckBox chkBoxThresh;
        private System.Windows.Forms.TrackBar tbarThreshold;
        private System.Windows.Forms.ToolStrip tsSide;
        private System.Windows.Forms.ToolStripButton btnWorkRect;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripButton btnDone;
        private System.Windows.Forms.ToolStripButton btnDelete;
        private System.Windows.Forms.ToolStripButton btnRegist;
        private System.Windows.Forms.ToolStripButton btnDraw;
        private System.Windows.Forms.ToolStripButton btnSelect;
        private System.Windows.Forms.ToolStripComboBox cbPenType;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btnCopy;
        private System.Windows.Forms.ToolStripButton btnPaste;
        private System.Windows.Forms.ToolStripButton btnMask;
        private System.Windows.Forms.ToolStripComboBox cbMaskType;
    }
}

