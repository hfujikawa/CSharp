﻿//#define AVOID_OFS                       // 画像外の領域表示を禁止
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;                        // StreamWriter
using System.Xml.Serialization;     // XmlSerializer
using System.Drawing.Imaging;   // BitmapData
using System.Runtime.InteropServices;   // Marshal

namespace ImagePreviewListView
{
    //public enum IpZoom
    //{
    //    ZoomIn,
    //    ZoomOut
    //}

    public partial class MainForm : Form
    {
        public class Defect
        {
            public string name;
            public int index;
            public int area { get; set; }
            public Rectangle rect;
            public List<Point> lstPt;
            
            public Defect()
            {
                name = "";
                index = 0;
                area = 0;
                rect = new Rectangle();
                lstPt = new List<Point>();
            }
        }

        public class GroundTruth
        {
            public Rectangle workRect = new Rectangle();
            public Bitmap picture;
            public Defect[] defect = new Defect[10];
            public GroundTruth(){
                for(int i=0; i<10; i++)
                {
                    defect[i] = new Defect();
                }
            }
        }

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        static extern short GetKeyState(int key);
        //private DrawEngine drawEngine;
        private DrawObject drawing;
        private Bitmap preview;
        private Otsu ot = new Otsu();
        Point lastPoint = new Point();
        List<Point> linePts = new List<Point>();
        //List<List<Point>> lineGr = new List<List<Point>>();
        List<Point> binarizePtsIm = new List<Point>();
        List<Point> binarizePtsOld = new List<Point>();
        List<Point> contourPtsPb = new List<Point>();
        List<List<Point>> contours = new List<List<Point>>();
        List<Point> contourAll = new List<Point>();
        List<Point> mergePt = new List<Point>();
        int shapeType = 0;
        Bitmap canvas = null;
        Bitmap ovlyImage;
        Bitmap cropBmp;
        private Bitmap CombinedBitmap = null;
        private Point CropLocation = new Point(0, 0);
        Rectangle defectRectPb = new Rectangle();
        private Rectangle selectRectPb = new Rectangle();
        Point selectSttPtIm = new Point();
        Point selectEndPtIm = new Point();

        GroundTruth gt = new GroundTruth();
        int idxDt = 0;

        UserRect workRectPb;
        private bool rectMode = true;
        private bool selectMode = false;
        private bool isSelecting = false;
        private bool drawMode = false;
        bool isDraw = false;
        private Point ptSelectionStart = new Point();
        private Point ptSelectionEnd = new Point();
        private bool panelDragging = false;
        private Cursor dragCursor = null;
        private List<Point> erasePts = null;
        bool isLastErase = false;

        private string fileDir;

        private bool IsKeyPressed(int key)
        {
            bool keyPressed = false;
            short result = GetKeyState(key);

            switch (result)
            {
                case 0:
                    // Not pressed and not toggled
                    keyPressed = false;
                    break;

                case 1:
                    // Not presses but toggled
                    keyPressed = false;
                    break;

                default:
                    // Pressed
                    keyPressed = true;
                    break;
            }

            return keyPressed;
        }

        public int PanelWidth
        {
            get
            {
                if (pbZoom != null)
                {
                    return pbZoom.Width;
                }
                else
                {
                    return 0;
                }
            }
        }

        public int PanelHeight
        {
            get
            {
                if (pbZoom != null)
                {
                    return pbZoom.Height;
                }
                else
                {
                    return 0;
                }
            }
        }

        public double Zoom
        {
            get { return Math.Round(drawing.Zoom * 100, 0); }
            set
            {
                if (value > 0)
                {
                    // Make it a double!
                    double zoomDouble = (double)value / (double)100;

                    drawing.SetZoom(zoomDouble);
                    UpdatePanels(true);

                    //btnZoomIn.Focus();
                }
            }
        }

        public MainForm()
        {
            // DrawEngine & DrawObject initiralization
            //drawEngine = new DrawEngine();
            drawing = new DrawObject(this);

            InitializeComponent();
            workRectPb = new UserRect(new Rectangle(0, 0, pbZoom.Width-1, pbZoom.Height-1));
            workRectPb.SetPictureBox(this.pbZoom);

            //InitControl();
            Preview();
            SetupBmp();

            this.pbZoom.MouseWheel += new MouseEventHandler(pictureBox2_MouseWheel);
        }

        private void DisposeControl()
        {
            // No memory leaks here
            if (drawing != null)
            {
                drawing.Dispose();
            }

            //if (drawEngine != null)
            //{
            //    drawEngine.Dispose();
            //}

            if (preview != null)
            {
                preview.Dispose();
            }
            if ((canvas != null))
            {
                //cleanup
                canvas.Dispose();
            }
        }

        private void SetupBmp()
        {
            canvas = new Bitmap(pbZoom.Width, pbZoom.Height);
            //draw something - here just fill the background red
            using (Graphics g = Graphics.FromImage(canvas))
            {
                g.Clear(Color.FromArgb(0,0,0,0));
            }
        }

        public void InitControl()
        {
            // Make sure panel is DoubleBuffering
            //drawEngine.CreateDoubleBuffer(pictureBox2.CreateGraphics(), pictureBox2.Size.Width, pictureBox2.Size.Height);

        }

        void pictureBox2_MouseWheel(object sender, MouseEventArgs e)
        {
            if (drawing.Image != null && (this.IsKeyPressed(0xA2) || this.IsKeyPressed(0xA3)))
            {
                if (e.Delta < 0)
                {
                    drawing.ZoomOut();
                }
                else
                {
                    drawing.ZoomIn();
                }
            }

            UpdatePanels(true);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Console.WriteLine(Properties.Settings.Default.Number);
            chkLoad.Checked = Properties.Settings.Default.CheckBox;

            cbCentZoom.SelectedIndex = 0;
            cbPenType.SelectedIndex = 0;
            cbMaskType.SelectedIndex = 0;

            // ListViewコントロールのプロパティを設定
            listView1.FullRowSelect = true;
            listView1.GridLines = true;
            listView1.Sorting = SortOrder.None;
            listView1.View = View.Details;

            // 列（コラム）ヘッダの作成
            ColumnHeader columnMark = new ColumnHeader();
            ColumnHeader columnName = new ColumnHeader();
            columnMark.Text = "Status";
            columnMark.Width = 40;
            columnName.Text = "File Name";
            columnName.Width = 200;
            ColumnHeader[] colHeaderRegValue = { columnMark, columnName };
            listView1.Columns.AddRange(colHeaderRegValue);
            //listView1.CheckBoxes = true;
            listView1.MultiSelect = false;

            tbarThreshold.Enabled = false;
        }

        // 指定画像をラスタライズ
        private List<Point> rasterizeImage(Bitmap bmp, Point stt, Point end, Point offset)
        {
            if (bmp == null) return null;
            List<Point> lstPt = new List<Point>();
#if true
            for (int y = stt.Y; y < end.Y; y++)
            {
                for (int x = stt.X; x < end.X; x++)
                {
                    Color color = bmp.GetPixel(x, y);
                    if (color.R > 128)
                    {
                        lstPt.Add(new Point(x+offset.X, y+offset.Y));
                    }
                }
            }
#else
            BitmapData sourceData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height),
                                                       ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);

            byte[] pixelBuffer = new byte[sourceData.Stride * sourceData.Height];

            Marshal.Copy(sourceData.Scan0, pixelBuffer, 0, pixelBuffer.Length);
            bmp.UnlockBits(sourceData);
                            float r = 0, g = 0,b = 0;

                            for (int k = 0; k < pixelBuffer.Length; k += 4)
                            {
                                r = pixelBuffer[k];
                                g = pixelBuffer[k + 1];
                                b = pixelBuffer[k + 2];
                                if (r > 128)
                                {
                                    int x = k % sourceData.Stride;
                                    int y = k / sourceData.Stride;
                                    lstPt.Add(new Point(x + offset.X, y + offset.Y));
                                }
                            }
#endif
            return lstPt;
        }

        // 始点・終点で指定された領域の二値化
        private void clipRoiBinarize(Point start, Point end, int thresh)
        {
            Point startImgPt = cnvPb2Im(start);
            Point endImgPt = cnvPb2Im(end);
            Point loc = startImgPt;
            int width = endImgPt.X - startImgPt.X + 1;
            int height = endImgPt.Y - startImgPt.Y + 1;
            // Create the new bitmap and associated graphics object
            Bitmap cropBmp = new Bitmap(width, height);
            Graphics g = Graphics.FromImage(cropBmp);
            g.DrawImage(drawing.Image, 0, 0, new Rectangle(loc.X, loc.Y,width,height), GraphicsUnit.Pixel);
            // Clean up
            g.Dispose();
            ot.Convert2GrayScaleFast(cropBmp);
            int otsuThreshold = ot.getOtsuThreshold((Bitmap)cropBmp);
            if (thresh == 0) thresh = otsuThreshold;
            Bitmap resultClipBmp =ot.threshold(cropBmp, thresh);
            tbThreshold.Text =thresh.ToString();

            //binarizePtsIm.Clear();
            binarizePtsIm = rasterizeImage((Bitmap)resultClipBmp.Clone(), new Point(0, 0), new Point(width-1, height-1), startImgPt);

            var finalImage = new Bitmap(width, height);
            var graphics = Graphics.FromImage(finalImage);
            graphics.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceOver;
            graphics.DrawImage(cropBmp, 0, 0);
            graphics.DrawImage(resultClipBmp, 0, 0);

            //pictureBox1.Image = finalImage;
            pictureBox1.Image = resultClipBmp;
        }

        //<+ Combine crop images on overlay
        // Create the combined image.
        private void createCombinedImage(Point stt, Point end)
        {
            // If there's no background image, do nothing.
            if (ovlyImage == null) return;

            // Add the overlay.
            if (cropBmp != null)
            {
                CropLocation = cnvPb2Im(stt);
                int width = (int)((double)(end.X - stt.X+1) / drawing.Zoom);
                int height = (int)((double)(end.Y - stt.Y+1) / drawing.Zoom);
                using (Graphics gr = Graphics.FromImage(CombinedBitmap))
                {
                    gr.DrawImage(cropBmp, CropLocation.X, CropLocation.Y, width, height);
                }
            }

            // Display the result.
            pictureBox1.Image = CombinedBitmap;
        }
        //+>

        // 始点・終点で指定された領域の輪郭抽出
        private void clipRoiBoundary(Bitmap bmpClip, Point start, Point end)
        {
            int margin = 3;
            int width = end.X - start.X + 1 + margin*2;
            int height = end.Y - start.Y + 1 + margin*2;
            // Create the new bitmap and associated graphics object
            cropBmp = new Bitmap(width, height);
            Graphics g = Graphics.FromImage(cropBmp);
            g.DrawImage(bmpClip, 0, 0, new Rectangle(start.X - margin, start.Y - margin, width, height), GraphicsUnit.Pixel);
            cropBmp.Save("crop.bmp");
            pictureBox1.Image = cropBmp;
            //+ Combine crop images on overlay
            createCombinedImage(start, end);
            // Clean up
            g.Dispose();

            Bitmap dilate = cropBmp.DilateAndErodeFilter(3, ExtBitmap.MorphologyType.Dilation, false, false, true);
            Bitmap boundary = dilate.BitwiseBlend(cropBmp, ExtBitmap.BitwiseBlendType.None, ExtBitmap.BitwiseBlendType.None, ExtBitmap.BitwiseBlendType.Xor);

            //pictureBox1.Image = boundary;
            boundary.Save("boundary.bmp");

            width = boundary.Width; height = boundary.Height;
            start.X -= margin; start.Y -= margin;
            contourPtsPb = rasterizeImage(boundary, new Point(0, 0), new Point(width - 1, height - 1), start);
        }

        private void pictureBox2_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                //last point
                erasePts.Add(e.Location);
                //redraw
                this.Invalidate();
            }

            if (isDraw && drawMode)
            {
                isDraw = false;
                pbZoom.Invalidate();
            }
            if (selectMode)
            {
                // マウスドラッグ終了、表示更新
                drawing.EndDrag();
                clipRoiBinarize(ptSelectionStart, ptSelectionEnd, 0);
                UpdatePanels(true);

                if (dragCursor != null)
                {
                    pbZoom.Cursor = dragCursor;
                }
            }
            // ワーク矩形モード
            //if (rectMode)
            //{
            //}

            // 領域選択またはドラッグムーブ
            if (isSelecting == true)
            {
                // Calculate my selection rectangle
                //Rectangle rect = CalculateReversibleRectangle(ptSelectionStart, ptSelectionEnd);
                selectRectPb.Location = ptSelectionStart;
                selectRectPb.Width = ptSelectionEnd.X - ptSelectionStart.X + 1;
                selectRectPb.Height = ptSelectionEnd.Y - ptSelectionStart.Y + 1;
                selectSttPtIm = cnvPb2Im(ptSelectionStart);
                selectEndPtIm = cnvPb2Im(ptSelectionEnd);

                // Clear the selection rectangle
                ptSelectionEnd.X = -1;
                ptSelectionEnd.Y = -1;
                ptSelectionStart.X = -1;
                ptSelectionStart.Y = -1;

                // Stop selecting
                isSelecting = false;

                // Position of the panel to the screen
                //Point ptPbFull = PointToScreen(pictureBox2.Location);

                // Zoom to my selection
                //drawing.ZoomToSelection(rect, ptPbFull);

                // Refresh my screen & update my preview panel
                pbZoom.Refresh();
                UpdatePanels(true);
            }
        }

        private void pictureBox2_MouseMove(object sender, MouseEventArgs e)
        {
            toolStripStatusLabel1.Text = cnvPb2Im(e.Location).ToString();

            if (e.Button == MouseButtons.Right)
            {
                //store the intermediate points
                erasePts.Add(e.Location);
                //and redraw
                this.Invalidate();
            }

            if (drawing.Image != null)
            {
                Point ptCurrent = new Point();
                ptCurrent.X = (int)((double)(e.X - drawing.BoundingBox.X) / Zoom * 100);
                ptCurrent.Y = (int)((double)(e.Y - drawing.BoundingBox.Y) / Zoom * 100);
            }

            if (isDraw)
            {
                linePts.Add(e.Location);
                pbZoom.Invalidate();
            }

                                // ドラッグムーブ継続
            if (e.Button == MouseButtons.Middle)
            {
                    drawing.Drag(new Point(e.X, e.Y));
                    if (drawing.IsDragging)
                    {
                        UpdatePanels(false);
                    }
                    if (pbZoom.Cursor != dragCursor)
                    {
                        pbZoom.Cursor = dragCursor;
                    }
            }

            // ワーク矩形モード
            //if (rectMode)
            //{
            //    //pictureBox2.Invalidate();
            //}
            else if(selectMode)
            {
            // 領域選択またはドラッグムーブ
                if (isSelecting == true)
                {
                    // 領域選択継続
                    ptSelectionEnd.X = e.X;
                    ptSelectionEnd.Y = e.Y;

                    Rectangle pbFullRect = new Rectangle(0, 0, pbZoom.Width - 1, pbZoom.Height - 1);

                    // Am I still selecting within my panel?
                    if (pbFullRect.Contains(new Point(e.X, e.Y)))
                    {
                        selectRectPb.Location = ptSelectionStart;
                        selectRectPb.Width = ptSelectionEnd.X - ptSelectionStart.X + 1;
                        selectRectPb.Height = ptSelectionEnd.Y - ptSelectionStart.Y + 1;
                        pbZoom.Invalidate();
                    }
                    if (pbZoom.Cursor != Cursors.Cross)
                    {
                        pbZoom.Cursor = Cursors.Cross;
                    }
                }
            }
        }

        private void pictureBox2_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && drawMode)
            {
                isLastErase = true;
                //reset the list of points
                erasePts = new List<Point>();
                //store the first point
                erasePts.Add(e.Location);
            }

            if (e.Button == MouseButtons.Left && drawMode)
            {
                if (linePts.Count > 0)
                {
                    mergePt.AddRange(linePts); 
                }
                linePts.Clear();
                isLastErase = false;
                lastPoint = e.Location;
                isDraw = true;
            }

            // ドラッグムーブ
            if (e.Button == MouseButtons.Middle)
            {
                // ドラッグ開始
                drawing.BeginDrag(new Point(e.X, e.Y));

                pbZoom.Cursor = Cursors.Hand;
            }

            // ワーク矩形モード
            if (rectMode)
            {
            }

            // 領域選択
            if (e.Button == MouseButtons.Left && selectMode)
            {
                selectMode = true;
                pbZoom.Cursor = Cursors.Cross;

                isSelecting = true;

                // Initial seleciton
                ptSelectionStart.X = e.X;
                ptSelectionStart.Y = e.Y;

                // No selection end
                ptSelectionEnd.X = -1;
                ptSelectionEnd.Y = -1;
            }
         }

        private void UpdatePanels(bool updatePreview)
        {
            if (drawing.CurrentSize.Width > 0 && drawing.OriginalSize.Width > 0)
            {
                // Make sure panel is up to date
                pbZoom.Refresh();

                updateSelection();
                updateDefectRect();
                updateWorkRect();
                updateDefectContour();

                // Calculate zoom
                double zoom = Math.Round(((double)drawing.CurrentSize.Width / (double)drawing.OriginalSize.Width), 2);

                // Display zoom in percentages
                txtZoom.Text = (int)(zoom * 100) + "%";

                if (updatePreview && drawing.PreviewImage != null && pbPreview.Visible == true)
                {
                    // No memory leaks here
                    if (preview != null)
                    {
                        preview.Dispose();
                        preview = null;
                    }

                    // New preview
                    preview = new Bitmap(drawing.PreviewImage.Size.Width, drawing.PreviewImage.Size.Height);

                    // Make sure panel is the same size as the bitmap
                    if (pbPreview.Size != drawing.PreviewImage.Size)
                    {
                        pbPreview.Size = drawing.PreviewImage.Size;
                    }

                    // New Graphics from the new bitmap we created (Empty)
                    using (Graphics g = Graphics.FromImage(preview))
                    {
                        // Draw the image on the bitmap
                        g.DrawImage(drawing.PreviewImage, 0, 0, drawing.PreviewImage.Size.Width, drawing.PreviewImage.Size.Height);

                        double ratioX = (double)drawing.PreviewImage.Size.Width / (double)drawing.CurrentSize.Width;
                        double ratioY = (double)drawing.PreviewImage.Size.Height / (double)drawing.CurrentSize.Height;

                        double boxWidth = pbZoom.Width * ratioX;
                        double boxHeight = pbZoom.Height * ratioY;
                        double positionX = ((drawing.BoundingBox.X - (drawing.BoundingBox.X * 2)) * ratioX);
                        double positionY = ((drawing.BoundingBox.Y - (drawing.BoundingBox.Y * 2)) * ratioY);

                        // Making the red pen
                        Pen pen = new Pen(Color.Red, 1);
                        SolidBrush brush = new SolidBrush(Color.FromArgb(80, 0, 0, 255));

                        if (boxHeight >= drawing.PreviewImage.Size.Height)
                        {
                            boxHeight = drawing.PreviewImage.Size.Height - 1;
                            positionY = 0;              //+ bugfix
                        }
                        else if ((boxHeight + positionY) > drawing.PreviewImage.Size.Height)
                        {
                            boxHeight = drawing.PreviewImage.Size.Height - (positionY);
                        }

                        if (boxWidth >= drawing.PreviewImage.Size.Width)
                        {
                            boxWidth = drawing.PreviewImage.Size.Width - 1;
                            positionX = 0;              //+ bugfix
                        }
                        else if ((boxWidth + positionX) > drawing.PreviewImage.Size.Width)
                        {
                            boxWidth = drawing.PreviewImage.Size.Width - (positionX);
                        }

                        // Draw the rectangle on the bitmap
                        //g.DrawRectangle(pen, new Rectangle((int)positionX, (int)positionY, (int)boxWidth, (int)boxHeight));
                        g.FillRectangle(brush, new Rectangle((int)positionX, (int)positionY, (int)boxWidth, (int)boxHeight));
                    }

                    // Display the bitmap
                    pbPreview.Image = preview;
                }
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.gif;*.bmp;*.png;*.tif;*.tiff;*.wmf;*.emf|JPEG Files (*.jpg)|*.jpg;*.jpeg|GIF Files (*.gif)|*.gif|BMP Files (*.bmp)|*.bmp|PNG Files (*.png)|*.png|TIF files (*.tif;*.tiff)|*.tif;*.tiff|EMF/WMF Files (*.wmf;*.emf)|*.wmf;*.emf|All files (*.*)|*.*";

            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                this.ImagePath = openFileDialog.FileName;
                gt.workRect.X = 0;
                gt.workRect.Y = 0;
                gt.workRect.Width = drawing.ImageWidth;
                gt.workRect.Height = drawing.ImageHeight;
                updateWorkRect();
                if (gt.picture == null)
                    gt.picture = new Bitmap(drawing.Image.Width, drawing.Image.Height);
                //<+ Combine crop images on overlay
                ovlyImage = new Bitmap(drawing.ImageWidth, drawing.ImageHeight);
                // Copy the background.
                CombinedBitmap = new Bitmap(ovlyImage);
                //+>
                pbZoom.Invalidate();
            }

            UpdatePanels(true);
        }

        public string ImagePath
        {
            set
            {
                drawing.ImagePath = value;

                UpdatePanels(true);
            }
        }

        public Bitmap Image
        {
            get
            {
                return drawing.Image;
            }
            set
            {
                drawing.Image = value;

                UpdatePanels(true);
            }
        }

        private void Preview()
        {
            // Hide preview panel mechanics
            // Making sure that UpdatePanels doesn't get called when it's hidden!

            pbPreview.Show();

            //InitControl();
#if AVOID_OFS
            drawing.AvoidOutOfScreen();
#endif
            pbZoom.Refresh();

            UpdatePanels(true);
        }

        private void DrawGraphics(Graphics g)
        {
            // 二値化対象ＲＯＩの描画
            g.DrawRectangle(Pens.Blue, selectRectPb);
            // 選択不良外接矩形の描画
            g.DrawRectangle(Pens.Red, defectRectPb);

            // 不良の輪郭描画
            if (contourAll.Count > 0)
            {
                for(int i=0; i<contourAll.Count; i++)
                g.DrawRectangle(Pens.Blue, contourAll[i].X, contourAll[i].Y, 1, 1);
            }
        }

        private void pictureBox2_Paint(object sender, PaintEventArgs e)
        {
            drawing.Draw(e.Graphics);

            if (drawing.Image != null)
            {
                DrawGraphics(e.Graphics);
            }

            //if we have an image to paint
            if ((canvas != null))
            {
                DrawCanvas();
                e.Graphics.DrawImage(canvas, 0, 0);
            }
        }

        private void DrawCanvas()
        {
            using (Graphics g = Graphics.FromImage(canvas))
            {
                g.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceCopy;
                if (isLastErase)
                {
                    if ((erasePts != null) && erasePts.Count > 1)
                    {
                        using (Pen p = new Pen(Color.Transparent, 4))
                        {
                            g.DrawCurve(p, erasePts.ToArray());
                        }
                    }
                }
                else
                {
                    Color[] color = { Color.Black, Color.Red, Color.Green, Color.Blue };
                    if (linePts.Count > 1)
                    {
                        switch (shapeType)
                        {
                            case 0:
                                g.DrawCurve(Pens.Red, linePts.ToArray());
                                break;
                            case 1:
                                if (isDraw)
                                    g.DrawCurve(Pens.Red, linePts.ToArray());
                                else
                                {
                                    g.FillPolygon(Brushes.Red, linePts.ToArray());
                                }
                                break;
                        }
                    }
                    Brush brushZero = new SolidBrush(Color.FromArgb(0, 0, 0, 0));
                    g.FillRectangle(brushZero, selectRectPb);

                    if (binarizePtsIm.Count > 0)
                    {
                        for (int i = 0; i < binarizePtsIm.Count; i++)
                        {
                            Point ptPb = cnvIm2Pb(binarizePtsIm[i]);
                            g.DrawRectangle(Pens.Red, ptPb.X, ptPb.Y, 1, 1);
                        }
                        binarizePtsOld = binarizePtsIm.ToList();
                    }

                }
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            drawing.ZoomIn();

            // AfterZoom Event
            if (drawing.Image != null)
            {
                drawing.ZoomIn();
            }
            UpdatePanels(true);
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            drawing.ZoomOut();

            // AfterZoom Event
            if (drawing.Image != null)
            {
                drawing.ZoomOut();
            }
            UpdatePanels(true);
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            drawing.FitToScreen();
            UpdatePanels(true);
        }

        private void pictureBox3_MouseDown(object sender, MouseEventArgs e)
        {
            if (panelDragging == false)
            {
                drawing.JumpToOrigin(e.X, e.Y, pbPreview.Width, pbPreview.Height, pbZoom.Width, pbZoom.Height);
                UpdatePanels(true);

                panelDragging = true;
            }
        }

        private void pictureBox3_MouseMove(object sender, MouseEventArgs e)
        {
            if (panelDragging)
            {
                drawing.JumpToOrigin(e.X, e.Y, pbPreview.Width, pbPreview.Height, pbZoom.Width, pbZoom.Height);
                UpdatePanels(true);
            }
        }

        private void pictureBox3_MouseUp(object sender, MouseEventArgs e)
        {
            panelDragging = false;
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            double zoom = 1.0;
            double originalZoom = drawing.Zoom;

            if (drawing.Zoom != zoom)
            {
                drawing.SetZoom(zoom);
            }
            UpdatePanels(true);
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            //InitControl();
            drawing.FitToScreen();
            UpdatePanels(true);
        }

        private void listView1_MouseLeave(object sender, EventArgs e)
        {
            pbZoom.Focus();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            double zoom = (double)trackBar1.Value/100;
            drawing.SetZoom(zoom);
            UpdatePanels(true);
        }

        private void cbCentZoom_SelectedIndexChanged(object sender, EventArgs e)
        {
            drawing.centZoom = cbCentZoom.SelectedIndex;
            drawing.SetZoom(drawing.Zoom);
            UpdatePanels(true);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Properties.Settings.Default.Number = 10;
            Properties.Settings.Default.CheckBox = chkLoad.Checked;
            Properties.Settings.Default.Save();
        }

        private void stripBtnNew_Click(object sender, EventArgs e)
        {
            //FolderBrowserDialogクラスのインスタンスを作成
            FolderBrowserDialog fbd = new FolderBrowserDialog();

            //上部に表示する説明テキストを指定する
            fbd.Description = "フォルダを指定してください。";
            //ルートフォルダを指定する
            //デフォルトでDesktop
            fbd.RootFolder = Environment.SpecialFolder.Desktop;
            //最初に選択するフォルダを指定する
            //RootFolder以下にあるフォルダである必要がある
            fbd.SelectedPath = @"C:\Users\hfuji_o84v4h0\Pictures";
            //ユーザーが新しいフォルダを作成できるようにする
            //デフォルトでTrue
            fbd.ShowNewFolderButton = true;

            //ダイアログを表示する
            if (fbd.ShowDialog(this) == DialogResult.OK)
            {
                //選択されたフォルダを表示する
                Console.WriteLine(fbd.SelectedPath);
                fileDir = fbd.SelectedPath;
            } 
            //DirectoryInfo dinfo = new DirectoryInfo(@"C:\Users\hfuji_o84v4h0\Pictures\NEU surface defect database");
            DirectoryInfo dinfo = new DirectoryInfo(fbd.SelectedPath);
            FileInfo[] Files = dinfo.GetFiles("*.bmp");
            foreach (FileInfo file in Files)
            {
                string pattern = "1.bmp";
                if (System.Text.RegularExpressions.Regex.IsMatch(file.Name, pattern)) continue;
#if false
                listBox1.Items.Add(file.Name);
#else
                //リストビューの項目に追加
                ListViewItem Listdata = new ListViewItem();
                Listdata.Text = "";
                Listdata.Text = "-";
                Listdata.SubItems.Add(file.Name);
                listView1.Items.Add(Listdata);
#endif
            }
            if (listView1.Items.Count > 0)
            {
                listView1.Items[0].Selected = true;
                listView1.Select();
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedIndices.Count > 0)
            {
                ListViewItem Listdata = listView1.SelectedItems[0];
                string fileName = Listdata.SubItems[1].Text;
                string fileFullPath = Path.Combine(fileDir, fileName);
                this.ImagePath = fileFullPath;
                gt.workRect.X = 0;
                gt.workRect.Y = 0;
                gt.workRect.Width = drawing.ImageWidth;
                gt.workRect.Height = drawing.ImageHeight;
                updateWorkRect();
                if(gt.picture == null)
                    gt.picture = new Bitmap(drawing.Image.Width, drawing.Image.Height);
                pbZoom.Invalidate();
            }
        }

        private void chkBoxThresh_CheckedChanged(object sender, EventArgs e)
        {
            if (chkBoxThresh.Checked)
            {
                tbarThreshold.Enabled = true;
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void cbShapeType_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private Point cnvIm2Pb(Point pt)
        {
            Point ptPb = new Point();
            ptPb.X = (int)((double)drawing.BoundingBox.X + (double)pt.X * drawing.Zoom);
            ptPb.Y = (int)((double)drawing.BoundingBox.Y + (double)pt.Y * drawing.Zoom);
            return ptPb;
        }

        private Point cnvPb2Im(Point pt)
        {
            Point ptIm = new Point();
            ptIm.X = (int)((double)(pt.X - drawing.BoundingBox.X) / drawing.Zoom);
            ptIm.Y = (int)((double)(pt.Y - drawing.BoundingBox.Y) / drawing.Zoom);
            return ptIm;
        }

        private void drawDefectOnOverlay()
        {
            Graphics g = Graphics.FromImage(ovlyImage);
            for (int i = 0; i < lbDefect.Items.Count; i++)
            {
                if (gt.defect[i].lstPt.Count > 1)
                {
                    //g.FillPolygon(Brushes.Red, gt.defect[i].lstPt.ToArray());
                    for(int j=0; j<gt.defect[i].lstPt.Count; j++)
                    {
                        g.FillRectangle(Brushes.Red, gt.defect[i].lstPt[j].X, gt.defect[i].lstPt[j].Y, 1, 1);
                    }
                }
            }

            ovlyImage.Save("overlay.png");
            g.Dispose();
            gt.picture = (Bitmap)ovlyImage.Clone();
            pictureBox1.Image = gt.picture;
            //lineGr.Clear();
        }

        //private void btnAdd_Click(object sender, EventArgs e)
        //{
        //}

        private void updateWorkRect()
        {
            Point loc = cnvIm2Pb(new Point(gt.workRect.X, gt.workRect.Y));
            workRectPb.rect.X = loc.X; workRectPb.rect.Y = loc.Y;
            workRectPb.rect.Width = (int)((double)gt.workRect.Width * drawing.Zoom);
            workRectPb.rect.Height = (int)((double)gt.workRect.Height * drawing.Zoom);
            pbZoom.Invalidate();
        }

        private void updateDefectRect()
        {
            if (lbDefect.Items.Count > 0 && lbDefect.SelectedIndex > -1)
            {
                int index = lbDefect.SelectedIndex;
                Point loc = cnvIm2Pb(new Point(gt.defect[index].rect.X, gt.defect[index].rect.Y));
                defectRectPb.X = loc.X; defectRectPb.Y = loc.Y;
                defectRectPb.Width = (int)((double)gt.defect[index].rect.Width * drawing.Zoom);
                defectRectPb.Height = (int)((double)gt.defect[index].rect.Height * drawing.Zoom);
                pbZoom.Invalidate();
            }
        }

        private void updateDefectContour()
        {
            if (contours.Count < 1) return;
            contourAll.Clear();
            foreach (List<Point> lstPts in contours)
            {
                for (int i = 0; i < lstPts.Count; i++)
                {
                    Point loc = cnvIm2Pb(lstPts[i]);
                    contourAll.Add(loc);
                }
            }
        }

        private void updateSelection()
        {
            Point loc1 = cnvIm2Pb(selectSttPtIm);
            Point loc2 = cnvIm2Pb(selectEndPtIm);
            selectRectPb.Location = loc1;
            selectRectPb.Width =  loc2.X - loc1.X + 1;
            selectRectPb.Height = loc2.Y - loc1.Y + 1;
            pbZoom.Invalidate();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdatePanels(false);
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
        }

        private void tbarThreshold_ValueChanged(object sender, EventArgs e)
        {
            tbThreshold.Text = tbarThreshold.Value.ToString();
            Point locEnd = new Point(selectRectPb.X + selectRectPb.Width - 1, selectRectPb.Y + selectRectPb.Height - 1);
            clipRoiBinarize(selectRectPb.Location, locEnd, tbarThreshold.Value);
            UpdatePanels(true);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int idxDt = lbDefect.SelectedIndex;
            if (idxDt < 0) return;
            gt.defect[idxDt].area = 0;
            gt.defect[idxDt].lstPt.Clear();

            if (ovlyImage == null) return;
            Graphics g = Graphics.FromImage(ovlyImage);
            g.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceCopy;
            Rectangle rectRemove = gt.defect[idxDt].rect;
            g.DrawRectangle(Pens.Black, rectRemove);
            //g.FillRectangle(Brushes.Black, rectRemove);
            Brush brushZero = new SolidBrush(Color.FromArgb(0, 0, 0, 0));
            g.FillRectangle(brushZero, rectRemove);
            ovlyImage.Save("overlay.png");
            g.Dispose();
            gt.defect[idxDt].rect = new Rectangle();

            gt.picture = (Bitmap)ovlyImage;
            pictureBox1.Image = gt.picture;
        }

        private void btnRegist_Click(object sender, EventArgs e)
        {
            if (linePts.Count < 1 && binarizePtsIm.Count < 1) return;

            if (linePts.Count > 0)
            {
                mergePt.AddRange(linePts);
            }
            if (binarizePtsIm.Count > 0)
            {
                List<Point> resultPb = new List<Point>();
                for (int i = 0; i < binarizePtsIm.Count; i++)
                {
                    resultPb.Add(cnvIm2Pb(binarizePtsIm[i]));
                }
                mergePt.AddRange(resultPb);
            }

            int xmin = mergePt.Min(point => point.X);
            int xmax = mergePt.Max(point => point.X);
            int ymin = mergePt.Min(point => point.Y);
            int ymax = mergePt.Max(point => point.Y);
            List<Point> allPts = rasterizeImage(canvas, new Point(xmin, ymin), new Point(xmax, ymax), new Point(0, 0));

            // 輪郭抽出
            clipRoiBoundary(canvas, new Point(xmin, ymin), new Point(xmax, ymax));

            // ラスタライズによる座標抽出
            if (contourPtsPb.Count > 0)
            {
                List<Point> resultIm = new List<Point>();
                for (int i = 0; i < contourPtsPb.Count; i++)
                {
                    resultIm.Add(cnvPb2Im(contourPtsPb[i]));
                }
                contours.Add(resultIm);
            }
            else return;

            gt.defect[idxDt] = new Defect();
            gt.defect[idxDt].name = "scratch";
            gt.defect[idxDt].index = idxDt;
            gt.defect[idxDt].area = contours[idxDt].Count;
            Point minIm = cnvPb2Im((new Point(xmin, ymin)));
            Point maxIm = cnvPb2Im(new Point(xmax, ymax));
            gt.defect[idxDt].rect.X = minIm.X;
            gt.defect[idxDt].rect.Y = minIm.Y;
            gt.defect[idxDt].rect.Width = maxIm.X - minIm.X + 1;
            gt.defect[idxDt].rect.Height = maxIm.Y - minIm.Y + 1;
            gt.defect[idxDt].lstPt = contours[idxDt].ToList();
            pbZoom.Invalidate();
            lbDefect.Items.Add(gt.defect[idxDt].name + gt.defect[idxDt].index.ToString() + ": " + gt.defect[idxDt].area.ToString());
            if (lbDefect.Items.Count > 0)
                lbDefect.SelectedIndex = lbDefect.Items.Count - 1;
            idxDt++;
            linePts.Clear();
            binarizePtsIm.Clear();
            mergePt.Clear();
        }

        private void cbPenType_SelectedIndexChanged(object sender, EventArgs e)
        {
            shapeType = cbPenType.SelectedIndex;
        }

        private void btnWorkRect_CheckedChanged(object sender, EventArgs e)
        {
            if (btnWorkRect.Checked)
            {
                btnWorkRect.Image = ImagePreviewListView.Properties.Resources.WorkRectOn32;
            }
            else
            {
                btnWorkRect.Image = ImagePreviewListView.Properties.Resources.WorkRectOff32;
            }
            rectMode = btnWorkRect.Checked;
            if (rectMode)
            {
                btnSelect.Checked = btnDraw.Checked = false;
            }
            selectMode = btnSelect.Checked;
            drawMode = btnDraw.Checked;
            workRectPb.sizeNodeRect = rectMode ? 5 : 0;
            workRectPb.mMove = rectMode;
            pbZoom.Invalidate();

        }

        private void btnDraw_CheckedChanged(object sender, EventArgs e)
        {
            drawMode = btnDraw.Checked;
            if (drawMode)
            {
                btnWorkRect.Checked = btnSelect.Checked = false;
            }
            rectMode = btnWorkRect.Checked;
            selectMode = btnSelect.Checked;
        }

        private void btnSelect_CheckedChanged(object sender, EventArgs e)
        {
            selectMode = btnSelect.Checked;
            if (selectMode)
            {
                btnWorkRect.Checked = btnDraw.Checked = false;
            }
            rectMode = btnWorkRect.Checked;
            drawMode = btnDraw.Checked;
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            drawDefectOnOverlay();
        }

    }

}
