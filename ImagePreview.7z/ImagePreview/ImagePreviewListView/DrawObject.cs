﻿//#define AVOID_OFS                       // 画像外への移動・領域表示を禁止
using System;
using System.Drawing;
using System.IO;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

namespace ImagePreviewListView
{
    public class DrawObject
    {
        private MainForm ImageZoom;
        private	Rectangle boundingRect;
		private	Point dragPoint;
		private	bool dragging;
        private Bitmap bmp;
        private Bitmap bmpPreview;

        public int centZoom = 0;
        private double zoom = 1.0;
        private int panelWidth
        {
            get
            {
                return ImageZoom.PanelWidth;
            }
        }
        private int panelHeight
        {
            get
            {
                return ImageZoom.PanelHeight;
            }
        }
        //private int rotation = 0;

        public Rectangle BoundingBox
        {
            get { return boundingRect; }
        }

        public void Dispose()
        {
            if (this.Image != null)
            {
                this.Image.Dispose();
            }
        }

        public bool IsDragging
        {
            get { return dragging; }
        }

        public Size OriginalSize
        {
            get
            {
                if (this.Image != null)
                {
                        return this.Image.Size;
                 }
                else
                {
                    return Size.Empty;
                }
            }
        }

        public Size CurrentSize
        {
            get { if (boundingRect != null) { return new Size(boundingRect.Width, boundingRect.Height); } else { return Size.Empty; } }
        }

        public double Zoom
        {
            get { return zoom; }
        }

        public int ImageWidth
        {
            get
            {
                return this.Image.Width;
            }
        }

        public int ImageHeight
        {
            get
            {
                return this.Image.Height;
            }
        }

        public Bitmap Image
        {
            get 
            {
                return bmp;
            }
            set
            {
                try
                {
                    if (value != null)
                    {
                        // No memory leaks here!
                        if (this.bmp != null)
                        {
                            this.bmp.Dispose();
                            this.bmp = null;
                        }

                        this.bmp = value;

                        boundingRect = new Rectangle(0, 0, (int)(this.ImageWidth * zoom), (int)(this.ImageHeight * zoom));

                        zoom = 1.0;
                        bmpPreview = CreatePreviewImage();
                        FitToScreen();
                    }
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show("ImageViewer error: " + ex.ToString());
                }
            }
        }
        
        public Image PreviewImage
        {
            get { return bmpPreview; }
        }

        public string ImagePath
        {
            set
            {
                try
                {
                    // No memory leaks here!
                    if (this.bmp != null)
                    {
                        this.bmp.Dispose();
                        this.bmp = null;
                    }

                    Bitmap temp = null;
                    Bitmap mask = null;

                    // Make sure it does not crash on incorrect image formats
                    try
                    {
                        //temp = (Bitmap)Bitmap.FromFile(value);
                        temp = new Bitmap(value);
                        string dirPath = Path.GetDirectoryName(value);
                        string maskFileName = Path.GetFileNameWithoutExtension(value) + "mask.png";
                        string maskFileFullPath = Path.Combine(dirPath, maskFileName);
                        if (File.Exists(maskFileFullPath))
                        {
                            mask = new Bitmap(maskFileFullPath);
                        }
                        else
                            mask = null;
                    }
                    catch
                    {
                        temp = null;
                        System.Windows.Forms.MessageBox.Show("ImageViewer error: Incorrect image format!");
                    }

                    if (temp != null)
                    {
                        this.bmp = temp;

                        boundingRect = new Rectangle(0, 0, (int)(this.ImageWidth * zoom), (int)(this.ImageHeight * zoom));

                        zoom = 1.0;
                        bmpPreview = CreatePreviewImage();
                        FitToScreen();
                    }
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show("ImageViewer error: " + ex.ToString());
                }
            }
        }

        public DrawObject(MainForm ImageZoom, Bitmap bmp)
        {
            try
            {
                this.ImageZoom = ImageZoom;

                // Initial dragging to false and an Image.
                dragging = false;
                this.Image = bmp;

                boundingRect = new Rectangle(0, 0, (int)(this.ImageWidth * zoom), (int)(this.ImageHeight * zoom));
            }
            catch(Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("ImageViewer error: " + ex.ToString());
            }
        }

        private System.Drawing.Imaging.ImageCodecInfo GetCodec(string type)
        {
            System.Drawing.Imaging.ImageCodecInfo[] info = System.Drawing.Imaging.ImageCodecInfo.GetImageEncoders();

            for (int i = 0; i < info.Length; i++)
            {
                string EnumName = type.ToString();
                if (info[i].FormatDescription.Equals(EnumName))
                {
                    return info[i];
                }
            }
            return null;
        }

        public DrawObject(MainForm ImageZoom)
        {
            try
            {
                this.ImageZoom = ImageZoom;
                // Initial dragging to false and No image.
                dragging = false;
                this.bmp = null;
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("ImageViewer error: " + ex.ToString());
            }
        }

        private Bitmap CreatePreviewImage()
        {
            // 148 && 117 as initial and default size for the preview panel.
            Rectangle previewRect = new Rectangle(0, 0, 148, 117);

            double x_ratio = (double)previewRect.Width / (double)this.BoundingBox.Width;
            double y_ratio = (double)previewRect.Height / (double)this.BoundingBox.Height;

            if ((this.BoundingBox.Width <= previewRect.Width) && (this.BoundingBox.Height <= previewRect.Height))
            {
                previewRect.Width = this.BoundingBox.Width;
                previewRect.Height = this.BoundingBox.Height;
            }
            else if ((x_ratio * this.BoundingBox.Height) < previewRect.Height)
            {
                previewRect.Height = Convert.ToInt32(Math.Ceiling(x_ratio * this.BoundingBox.Height));
                previewRect.Width = previewRect.Width;
            }
            else
            {
                previewRect.Width = Convert.ToInt32(Math.Ceiling(y_ratio * this.BoundingBox.Width));
                previewRect.Height = previewRect.Height;
            }

            Bitmap bmp = new Bitmap(previewRect.Width, previewRect.Height);

            using (Graphics g = Graphics.FromImage(bmp))
            {
                if (this.Image != null)
                {
                    g.DrawImage(this.Image, previewRect);
                }
            }

            return bmp;
        }

        public void JumpToOrigin(int x, int y, int width, int height, int pWidth, int pHeight)
        {
            try
            {
                double zoom = (double)boundingRect.Width / (double)width;

                int originX = (int)(x * zoom);
                int originY = (int)(y * zoom);

                originX = originX - (originX * 2);
                originY = originY - (originY * 2);

                boundingRect.X = originX + (pWidth / 2);
                boundingRect.Y = originY + (pHeight / 2);
#if AVOID_OFS
                AvoidOutOfScreen();
#endif
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("ImageViewer error: " + ex.ToString());
            }
        }

        public void JumpToOrigin(int x, int y, int width, int height)
        {
            try
            {
                boundingRect.X = (x - (width / 2)) - ((x - (width / 2)) * 2);
                boundingRect.Y = (y - (height / 2)) - ((y - (height / 2)) * 2);
#if AVOID_OFS
                AvoidOutOfScreen();
#endif
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("ImageViewer error: " + ex.ToString());
            }
        }

        public Point PointToOrigin(int x, int y, int width, int height)
        {
#if true
            switch (centZoom)
            {
                case 0:             // 原点
                    return new Point(0, 0);
                case 1:             // 画像中心
                    int originX = -(int)(Image.Width/2*zoom) + panelWidth / 2;
                    int originY = -(int)(Image.Height/2*zoom) + panelHeight / 2;

                    return new Point(originX, originY);
            }
            return new Point(0, 0);
#else
            try
            {
                double zoomX = (double)width / (double)boundingRect.Width;
                double zoomY = (double)height / (double)boundingRect.Height;

                if (width > panelWidth)
                {
                    int oldX = (boundingRect.X - (boundingRect.X * 2)) + (panelWidth / 2);
                    int oldY = (boundingRect.Y - (boundingRect.Y * 2)) + (panelHeight / 2);

                    int newX = (int)(oldX * zoomX);
                    int newY = (int)(oldY * zoomY);

                    int originX = newX - (panelWidth / 2) - ((newX - (panelWidth / 2)) * 2);
                    int originY = newY - (panelHeight / 2) - ((newY - (panelHeight / 2)) * 2);

                    return new Point(originX, originY);
                }
                else
                {
                    if (height > panelHeight)
                    {
                        int oldY = (boundingRect.Y - (boundingRect.Y * 2)) + (panelHeight / 2);

                        int newY = (int)(oldY * zoomY);

                        int originY = newY - (panelHeight / 2) - ((newY - (panelHeight / 2)) * 2);

                        return new Point(0, originY);
                    }
                    else
                    {
                        return new Point(0, 0);
                    }
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("ImageViewer error: " + ex.ToString());
                return new Point(0, 0);
            }
#endif
        }

        public void ZoomIn()
        {
            try
            {
                if (this.Image != null)
                {
                    // Make sure zoom steps are with 10%
                    decimal mZoom = 1m;
                    if ((decimal)zoom + 0.1m <= 4m)
                    {
                        if ((((decimal)zoom + 0.1m) % 0.1m) != 0)
                        {
                            mZoom = (decimal)zoom - ((decimal)zoom % 0.1m) + 0.1m; ;
                        }
                        else
                        {
                            mZoom = (decimal)zoom + 0.1m;
                        }
                        zoom = (double)mZoom;
                    }

                    Point p = PointToOrigin(boundingRect.X, boundingRect.Y, (int)(this.ImageWidth * zoom), (int)(this.ImageHeight * zoom));

                    boundingRect = new Rectangle(p.X, p.Y, (int)(this.ImageWidth * zoom), (int)(this.ImageHeight * zoom));
#if AVOID_OFS
                    AvoidOutOfScreen();
#endif
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("ImageViewer error: " + ex.ToString());
            }
        }

        public void ZoomOut()
        {
            try
            {
                if (this.Image != null)
                {
                    // Make sure zoom steps are with 10% and higher than 0%
                    decimal mZoom = 1m;
                    if ((decimal)zoom - 0.1m > 0)
                    {
                        if ((((decimal)zoom - 0.1m) % 0.1m) != 0)
                        {
                            mZoom = (decimal)zoom - ((decimal)zoom % 0.1m) - 0.1m;
                        }
                        else
                        {
                            mZoom = (decimal)zoom - 0.1m;
                        }
                        zoom = (double)mZoom;
                    }

                    Point p = PointToOrigin(boundingRect.X, boundingRect.Y, (int)(this.ImageWidth * zoom), (int)(this.ImageHeight * zoom));

                    boundingRect = new Rectangle(p.X, p.Y, (int)(this.ImageWidth * zoom), (int)(this.ImageHeight * zoom));
#if AVOID_OFS
                    AvoidOutOfScreen();
#endif
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("ImageViewer error: " + ex.ToString());
            }
        }

        public void SetPosition(int x, int y)
        {
            boundingRect.X = -x;
            boundingRect.Y = -y;
        }

        public void SetPositionX(int x)
        {
            boundingRect.X = -x;
        }

        public void SetPositionY(int y)
        {
            boundingRect.Y = -y;
        }

        public void SetZoom(double z)
        {
            try
            {
                if (this.Image != null)
                {
                    zoom = z;

                    Point p = PointToOrigin(boundingRect.X, boundingRect.Y, (int)(this.ImageWidth * zoom), (int)(this.ImageHeight * zoom));

                    boundingRect = new Rectangle(p.X, p.Y, (int)(this.ImageWidth * zoom), (int)(this.ImageHeight * zoom));
#if AVOID_OFS
                    AvoidOutOfScreen();
#endif
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("ImageViewer error: " + ex.ToString());
            }
        }

        public void Scroll(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            try
            {
                if (this.Image != null)
                {
                    if (e.Delta < 0)
                    {
                        ZoomOut();
                    }
                    else
                    {
                        ZoomIn();
                    }
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("ImageViewer error: " + ex.ToString());
            }
        }

        public void FitToScreen()
        {
            try
            {
                if (this.Image != null)
                {
                    double x_ratio = (double)panelWidth / (double)this.ImageWidth;
                    double y_ratio = (double)panelHeight / (double)this.ImageHeight;

                    if ((this.ImageWidth <= panelWidth) && (this.ImageHeight <= panelHeight))
                    {
                        boundingRect.Width = this.ImageWidth;
                        boundingRect.Height = this.ImageHeight;
                    }
                    else if ((x_ratio * this.ImageHeight) < panelHeight)
                    {
                        boundingRect.Height = Convert.ToInt32(Math.Ceiling(x_ratio * this.ImageHeight));
                        boundingRect.Width = panelWidth;
                    }
                    else
                    {
                        boundingRect.Width = Convert.ToInt32(Math.Ceiling(y_ratio * this.ImageWidth));
                        boundingRect.Height = panelHeight;
                    }

#if false
                    boundingRect.X = 0;
                    boundingRect.Y = 0;
#else
                    Point p = PointToOrigin(boundingRect.X, boundingRect.Y, boundingRect.Width, boundingRect.Height);
                    boundingRect.X = p.X;
                    boundingRect.Y = p.Y;
#endif

                    zoom = ((double)boundingRect.Width / (double)this.ImageWidth);
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("ImageViewer error: " + ex.ToString());
            }
        }

        public void AvoidOutOfScreen()
        {
            int marginX = 10, marginY = 10;
            try
            {
                // Am I lined out to the left?
                if (boundingRect.X >= 0)
                {
                    boundingRect.X = marginX;
                }
                else if ((boundingRect.X <= (boundingRect.Width - panelWidth) - ((boundingRect.Width - panelWidth) * 2)))
                {
                    if ((boundingRect.Width - panelWidth) - ((boundingRect.Width - panelWidth) * 2) <= 0)
                    {
                        // I am too far to the left!
                        boundingRect.X = (boundingRect.Width - panelWidth) - ((boundingRect.Width - panelWidth) * 2) - marginX;
                    }
                    else
                    {
                        // I am too far to the right!
                        boundingRect.X = marginX;
                    }
                }

                // Am I lined out to the top?
                if (boundingRect.Y >= 0)
                {
                    boundingRect.Y = marginY;
                }
                else if ((boundingRect.Y <= (boundingRect.Height - panelHeight) - ((boundingRect.Height - panelHeight) * 2)))
                {
                    if ((boundingRect.Height - panelHeight) - ((boundingRect.Height - panelHeight) * 2) <= 0)
                    {
                        // I am too far to the top!
                        boundingRect.Y = (boundingRect.Height - panelHeight) - ((boundingRect.Height - panelHeight) * 2) - marginY;
                    }
                    else
                    {
                        // I am too far to the bottom!
                        boundingRect.Y = marginY;
                    }
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("ImageViewer error: " + ex.ToString());
            }
        }

		public void Drag(Point pt)
		{
            try
            {
                if (this.Image != null)
                {
                    if (dragging == true)
                    {
                        // Am I dragging it outside of the panel?
                        //if ((pt.X - dragPoint.X > (boundingRect.Width - panelWidth) - ((boundingRect.Width - panelWidth) * 2)) && (pt.X - dragPoint.X < 0))
                        if(true)
                        {
                            // No, everything is just fine
                            boundingRect.X = pt.X - dragPoint.X;
                        }
#if false
                        else if ((pt.X - dragPoint.X > 0))
                        {
                            // Now don't drag it out of the panel please
                            boundingRect.X = 0;
                        }
                        else if((pt.X - dragPoint.X < (boundingRect.Width - panelWidth) - ((boundingRect.Width - panelWidth) * 2)))
                        {
                            // I am dragging it out of my panel. How many pixels do I have left?
                            if ((boundingRect.Width - panelWidth) - ((boundingRect.Width - panelWidth) * 2) <= 0)
                            {
                                // Make it fit perfectly
                                boundingRect.X = (boundingRect.Width - panelWidth) - ((boundingRect.Width - panelWidth) * 2);
                            }
                        }
#endif
                        // Am I dragging it outside of the panel?
                        //if (pt.Y - dragPoint.Y > (boundingRect.Height - panelHeight) - ((boundingRect.Height - panelHeight) * 2) && (pt.Y - dragPoint.Y < 0))
                        if(true)
                        {
                            // No, everything is just fine
                            boundingRect.Y = pt.Y - dragPoint.Y;
                        }
#if false
                        else if ((pt.Y - dragPoint.Y > 0))
                        {
                            // Now don't drag it out of the panel please
                            boundingRect.Y = 0;
                        }
                        else if (pt.Y - dragPoint.Y < (boundingRect.Height - panelHeight) - ((boundingRect.Height - panelHeight) * 2))
                        {
                            // I am dragging it out of my panel. How many pixels do I have left?
                            if ((boundingRect.Height - panelHeight) - ((boundingRect.Height - panelHeight) * 2) <= 0)
                            {
                                // Make it fit perfectly
                                boundingRect.Y = (boundingRect.Height - panelHeight) - ((boundingRect.Height - panelHeight) * 2);
                            }
                        }
#endif
                    }
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("ImageViewer error: " + ex.ToString());
            }
		}

		public void BeginDrag(Point pt)
		{
            try
            {
                if (this.Image != null)
                {
                    // Initial drag position
                    dragPoint.X = pt.X - boundingRect.X;
                    dragPoint.Y = pt.Y - boundingRect.Y;
                    dragging = true;
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("ImageViewer error: " + ex.ToString());
            }
		}

		public void EndDrag()
        {
            try
            {
                if (this.Image != null)
                {
                    dragging = false;
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("ImageViewer error: " + ex.ToString());
            }
		}

		public void Draw(Graphics g)
		{
            try
            {
                if (this.bmp != null)
                {
                    g.DrawImage(this.bmp, boundingRect);
                    g.DrawRectangle(Pens.Blue, boundingRect);
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("ImageViewer error: " + ex.ToString());
            }
		}
    }
}
