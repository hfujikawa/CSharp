﻿// https://social.msdn.microsoft.com/Forums/en-US/43d5f06c-681a-4bbb-ae5d-8d41e07b62d8/code-for-eraser-in-paint-application-using-ms-visual-c-2010-express?forum=Vsexpressvcs
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EraserInPaint
{
    public partial class Form1 : Form
    {
        //holds the points from the mouse-actions
        private List<Point> pts = null;
        //field to store the image we use
        Image canvas = null;
        Point lastPoint = new Point();
        Point currPoint = new Point();
        List<Point> lineSeg = new List<Point>();
        List<List<Point>> lineGr = new List<List<Point>>();
        bool isDraw = false;
        bool isLastErase = false;
    
        public Form1()
        {
            InitializeComponent();
            this.MouseDown += new MouseEventHandler(Form1_MouseDown);
            this.MouseMove += new MouseEventHandler(Form1_MouseMove);
            this.MouseUp += new MouseEventHandler(Form1_MouseUp);
            this.Paint += new PaintEventHandler(Form1_Paint);
            this.FormClosing += new FormClosingEventHandler(Form1_FormClosing);
            this.DoubleBuffered = true;
            SetupBmp();
        }

        private void SetupBmp()
        {
            canvas = new Bitmap(ClientSize.Width, ClientSize.Height);
            //draw something - here just fill the background red
            using (Graphics g = Graphics.FromImage(canvas))
            {
                g.Clear(Color.Red);
            }
        }

        void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if ((canvas != null))
            {
                //cleanup
                canvas.Dispose();
            }
        }

        void Form1_Paint(object sender, PaintEventArgs e)
        {
            tbCnt.Text = lineGr.Count.ToString();

            //if we have an image to paint
            if ((canvas != null))
            {
                using (Graphics g = Graphics.FromImage(canvas))
                {
                    g.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceCopy;
                    if (isLastErase)
                    {
                        if ((pts != null) && pts.Count > 1)
                        {
                            using (Pen p = new Pen(Color.Transparent, 4))
                            {
                                g.DrawCurve(p, pts.ToArray());
                            }
                        }
                    }
                    else
                    {
                        if (lineSeg.Count > 1)
                        {
                            g.DrawCurve(Pens.Green, lineSeg.ToArray());
                        }
                        //for (int i = 0; i < lineGr.Count; i++)
                        //{
                        //    if (lineGr[i].Count > 1)
                        //    {
                        //        g.DrawCurve(Pens.Black, lineGr[i].ToArray());
                        //    }
                        //}
                    }
                }
                e.Graphics.DrawImage(canvas, 0, 0);
            }
        }

        void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            isDraw = false;
            lineGr.Add(lineSeg.ToList());
            lineSeg.Clear();
            this.Invalidate();

            if (e.Button == MouseButtons.Right)
            {
                //last point
                pts.Add(e.Location);
                //redraw
                this.Invalidate();
            }
        }

        void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDraw)
            {
                currPoint = e.Location;
                lineSeg.Add(currPoint);
                this.Refresh();
            }
            if (e.Button == MouseButtons.Right)
            {
                //store the intermediate points
                pts.Add(e.Location);
                //and redraw
                this.Invalidate();
            }
        }

        void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && isDraw == false)
            {
                isLastErase = false;
                lineGr.Clear();
                lastPoint = e.Location;
                isDraw = true;
            }
            if (e.Button == MouseButtons.Right)
            {
                isLastErase = true;
                //reset the list of points
                pts = new List<Point>();
                //store the first point
                pts.Add(e.Location);
            }
        }
    }
}
