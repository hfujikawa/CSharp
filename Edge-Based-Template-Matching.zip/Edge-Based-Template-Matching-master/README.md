Edge Based Template Matching     
==============================



### About

There are some differences with the articles cited below.    

1.Finding edges directly using Canny Algorithm.  


2.There are some changes in the judgment of the score,But there is no mathematical basis.    
 

3 In fact, in addition to the optimization ideas in the cited articles,    
there are plenty of opportunities for optimization.


### Preview   
Note:Repeat runs to match multiple goals.
![click to preview](preview.gif)

### Library   

Prism   
EmguCV    

### References   

[Edge Based Template Matching](https://www.codeproject.com/Articles/99457/Edge-Based-Template-Matching)
