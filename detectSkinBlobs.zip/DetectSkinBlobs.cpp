/* Use Blob Detection to Detect Human Skin. by Shervin Emami, Oct 2010 (http://www.shervinemami.co.cc/).
   (Make sure the file "cvblobslib.lib" (from the cvBlobsLib Library) is added to your project).
 */

#include <iostream>

// Include OpenCV
#include "cv.h"
#include "highgui.h"

// Include cvBlobsLib
#include "BlobResult.h"


bool SHOW_EXTENDED_COLOR_IMAGES = false;	// Whether or not to also show the 3 extended Hue,Sat,Brightness images.


using namespace std;


// Print the label and then some text info about the IplImage properties, to std::cout for easy debugging.
void printImageInfo(const IplImage *image, const char *label)
{
	if (label)
	{
		std::cout << label << ": ";
	}
	if (image)
	{
		std::cout << "[Image] = " << image->width << "x" << image->height << "px, " << image->nChannels
			<< "channels of " << image->depth << "bit depth, widthStep=" << image->widthStep << ", origin=" << image->origin;
		if (image->roi)
		{
			std::cout << " ROI=[at " << image->roi->xOffset << "," << image->roi->yOffset
				<< " of size " << image->roi->width << "x" << image->roi->height << ", COI=" << image->roi->coi << "].";
		}
		else {
			std::cout << " ROI=<null>.";
		}
		std::cout << std::endl;
	}
	else
	{
		std::cout << "[Image] = <null>" << std::endl;
	}
}


int main(int argc, char *argv[])
{
	cout << "DetectSkinBlobs:  by Shervin Emami, Oct 2010 (http://www.shervinemami.co.cc/)." << endl;
	cout << "usage: DetectSkinBlobs [image]" << endl;

	// Get the filename.
	char *filename = "person.jpg";	// Use a default image file.
	if (argc > 1) {
		filename = argv[1];			// Use the file that was passed on the cmdline if given.
	}
	cout << "Opening file '" << filename << "'" << endl;

	// Open the color image file.
	IplImage *imageBGR = cvLoadImage(filename, CV_LOAD_IMAGE_COLOR);
	if (!imageBGR) {
		cout << "ERROR: Couldnt open the file " << filename << endl;
		return 1;	// Quit
	}

	// Create some GUI windows for output display.
	cvNamedWindow("Input Hue", CV_WINDOW_AUTOSIZE);
	cvNamedWindow("Input Saturation", CV_WINDOW_AUTOSIZE);
	cvNamedWindow("Input Value", CV_WINDOW_AUTOSIZE);
	cvNamedWindow("Output Hue", CV_WINDOW_AUTOSIZE);
	cvNamedWindow("Output Saturation", CV_WINDOW_AUTOSIZE);
	cvNamedWindow("Output Value", CV_WINDOW_AUTOSIZE);

	cvNamedWindow("Input Image", CV_WINDOW_AUTOSIZE);
	cvShowImage("Input Image", imageBGR);

	// Convert the image to HSV colors.
	IplImage* imageHSV = cvCreateImage( cvGetSize(imageBGR), 8, 3);	// Full HSV color image.
	cvCvtColor(imageBGR, imageHSV, CV_BGR2HSV);				// Convert from a BGR to an HSV image.

	// Get the separate HSV color components of the color input image.
	IplImage* planeH = cvCreateImage( cvGetSize(imageBGR), 8, 1);	// Hue component.
	IplImage* planeS = cvCreateImage( cvGetSize(imageBGR), 8, 1);	// Saturation component.
	IplImage* planeV = cvCreateImage( cvGetSize(imageBGR), 8, 1);	// Brightness component.
	cvCvtPixToPlane(imageHSV, planeH, planeS, planeV, 0);	// Extract the 3 color components.

	if (SHOW_EXTENDED_COLOR_IMAGES)
	{
		// Set the Saturation to max colorfulness and Brightness to max brightness, so we can see the color of every pixel.
		IplImage* planeH1 = cvCreateImage( cvGetSize(imageBGR), 8, 1);	// Hue component.
		IplImage* planeS1 = cvCreateImage( cvGetSize(imageBGR), 8, 1);	// Saturation component.
		IplImage* planeV1 = cvCreateImage( cvGetSize(imageBGR), 8, 1);	// Brightness component.
		cvCvtPixToPlane(imageHSV, planeH1, planeS1, planeV1, 0);	// Extract the 3 color components.
		cvSet(planeS1, CV_RGB(255,255,255));
		cvSet(planeV1, CV_RGB(255,255,255));
		IplImage* imageHSV1 = cvCreateImage( cvGetSize(imageBGR), 8, 3);	// Full HSV color image.
		IplImage* imageBGR1 = cvCreateImage( cvGetSize(imageBGR), 8, 3);	// Full RGB color image.
		cvCvtPlaneToPix( planeH1, planeS1, planeV1, 0, imageHSV1 );	// combine the separate color components.
		cvCvtColor(imageHSV1, imageBGR1, CV_HSV2BGR);				// Convert from a BGR to an HSV image.
		cvNamedWindow("Hue colored", CV_WINDOW_AUTOSIZE);
		cvShowImage("Hue colored", imageBGR1);
		cvReleaseImage(&planeH1);
		cvReleaseImage(&planeS1);
		cvReleaseImage(&planeV1);
		cvReleaseImage(&imageHSV1);
		cvReleaseImage(&imageBGR1);
	}
	if (SHOW_EXTENDED_COLOR_IMAGES)
	{
		// Set the Saturation to max, so we can see the saturation & color of every pixel.
		IplImage* planeH2 = cvCreateImage( cvGetSize(imageBGR), 8, 1);	// Hue component.
		IplImage* planeS2 = cvCreateImage( cvGetSize(imageBGR), 8, 1);	// Saturation component.
		IplImage* planeV2 = cvCreateImage( cvGetSize(imageBGR), 8, 1);	// Brightness component.
		cvCvtPixToPlane(imageHSV, planeH2, planeS2, planeV2, 0);	// Extract the 3 color components.
		cvSet(planeS2, CV_RGB(255,255,255));
		//cvSet(planeV2, CV_RGB(255,255,255));
		IplImage* imageHSV2 = cvCreateImage( cvGetSize(imageBGR), 8, 3);	// Full HSV color image.
		IplImage* imageBGR2 = cvCreateImage( cvGetSize(imageBGR), 8, 3);	// Full RGB color image.
		cvCvtPlaneToPix( planeH2, planeS2, planeV2, 0, imageHSV2 );	// combine the separate color components.
		cvCvtColor(imageHSV2, imageBGR2, CV_HSV2BGR);				// Convert from a BGR to an HSV image.
		cvNamedWindow("Saturation max", CV_WINDOW_AUTOSIZE);
		cvShowImage("Saturation max", imageBGR2);
		cvReleaseImage(&planeH2);
		cvReleaseImage(&planeS2);
		cvReleaseImage(&planeV2);
		cvReleaseImage(&imageHSV2);
		cvReleaseImage(&imageBGR2);
	}
	if (SHOW_EXTENDED_COLOR_IMAGES)
	{
		// Set the Brightness to max, so we can see the saturation & color of every pixel.
		IplImage* planeH3 = cvCreateImage( cvGetSize(imageBGR), 8, 1);	// Hue component.
		IplImage* planeS3 = cvCreateImage( cvGetSize(imageBGR), 8, 1);	// Saturation component.
		IplImage* planeV3 = cvCreateImage( cvGetSize(imageBGR), 8, 1);	// Brightness component.
		cvCvtPixToPlane(imageHSV, planeH3, planeS3, planeV3, 0);	// Extract the 3 color components.
		//cvSet(planeS3, CV_RGB(255,255,255));
		cvSet(planeV3, CV_RGB(255,255,255));
		IplImage* imageHSV3 = cvCreateImage( cvGetSize(imageBGR), 8, 3);	// Full HSV color image.
		IplImage* imageBGR3 = cvCreateImage( cvGetSize(imageBGR), 8, 3);	// Full RGB color image.
		cvCvtPlaneToPix( planeH3, planeS3, planeV3, 0, imageHSV3 );	// combine the separate color components.
		cvCvtColor(imageHSV3, imageBGR3, CV_HSV2BGR);				// Convert from a BGR to an HSV image.
		cvNamedWindow("Brightness max", CV_WINDOW_AUTOSIZE);
		cvShowImage("Brightness max", imageBGR3);
		cvReleaseImage(&planeH3);
		cvReleaseImage(&planeS3);
		cvReleaseImage(&planeV3);
		cvReleaseImage(&imageHSV3);
		cvReleaseImage(&imageBGR3);
	}

	// Show the input HSV channels
	cvShowImage("Input Hue", planeH);
	cvShowImage("Input Saturation", planeS);
	cvShowImage("Input Value", planeV);

	// Detect which pixels in each of the H, S and V channels are probably skin pixels.
	// Assume that skin has a Hue between 0 to 18 (out of 180), and Saturation above 50, and Brightness above 80.
	cvThreshold(planeH, planeH, 18, UCHAR_MAX, CV_THRESH_BINARY_INV);
	cvThreshold(planeS, planeS, 50, UCHAR_MAX, CV_THRESH_BINARY);
	cvThreshold(planeV, planeV, 80, UCHAR_MAX, CV_THRESH_BINARY);

	// Show the thresholded HSV channels
	cvShowImage("Output Hue", planeH);
	cvShowImage("Output Saturation", planeS);
	cvShowImage("Output Value", planeV);

	// Combine all 3 thresholded color components, so that an output pixel will only
	// be white if the H, S and V pixels were also white.
	IplImage* imageSkinPixels = cvCreateImage( cvGetSize(imageBGR), 8, 1);	// Greyscale output image.
	cvAnd(planeH, planeS, imageSkinPixels);				// imageSkin = H {BITWISE_AND} S.
	cvAnd(imageSkinPixels, planeV, imageSkinPixels);	// imageSkin = H {BITWISE_AND} S {BITWISE_AND} V.

	// Show the output image on the screen.
	cvNamedWindow("Skin Pixels", CV_WINDOW_AUTOSIZE);
	cvShowImage("Skin Pixels", imageSkinPixels);


	// Find blobs in the image.
	CBlobResult blobs;
	printImageInfo(imageSkinPixels, "imageSkinPixels");
	blobs = CBlobResult(imageSkinPixels, NULL, 0);	// Use a black background color.

	// Ignore the blobs whose area is less than minArea.
	int minArea = 100;
	blobs.Filter(blobs, B_EXCLUDE, CBlobGetArea(), B_LESS, minArea);

	// Show the large blobs.
	IplImage* imageSkinBlobs = cvCreateImage( cvGetSize(imageBGR), 8, 1);	// Greyscale output image.
	for (int i = 0; i < blobs.GetNumBlobs(); i++) {
		CBlob *currentBlob = blobs.GetBlob(i);
		currentBlob->FillBlob(imageSkinBlobs, CV_RGB(255,255,255));	// Draw the large blobs as white.
	}
    cvShowImage("Skin Blobs", imageSkinBlobs);

	// Wait until the user hits a key on the GUI window.
	cvWaitKey(0);	// Note that if you don't use cvWaitKey(), OpenCV will never display anything!

	// Free all the resources.
	cvReleaseImage( &imageBGR );
	cvReleaseImage( &imageHSV );
	cvReleaseImage( &planeH );
	cvReleaseImage( &planeS );
	cvReleaseImage( &planeV );
	cvReleaseImage( &imageSkinPixels );
	cvReleaseImage( &imageSkinBlobs );

	// Quit
	return 0;
}